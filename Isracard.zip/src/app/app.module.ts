import {  HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RepositoryService } from './services/RepositoryService';
import { SearchRepositoryComponent } from './pages/search-repository/search-repository.component';
import { BookMarkedRepositoriesComponent } from './pages/book-marked-repositories/book-marked-repositories.component';
import { ErrorComponent } from './pages/error/error.component'
import { SharedService } from './services/shared-service';

@NgModule({
  declarations: [
    AppComponent,

    SearchRepositoryComponent,
    BookMarkedRepositoriesComponent,
    ErrorComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [
    RepositoryService,
    SharedService],
  bootstrap: [AppComponent]
})
export class AppModule { }
