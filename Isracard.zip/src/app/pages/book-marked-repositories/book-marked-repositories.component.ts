import { Component, OnInit } from '@angular/core';
import { SharedService } from 'src/app/services/shared-service';
import { Repository } from 'src/app/services/Repository';
import { Router } from '@angular/router';

@Component({
  selector: 'app-book-marked-repositories',
  templateUrl: './book-marked-repositories.component.html',
  styleUrls: ['./book-marked-repositories.component.css']
})
export class BookMarkedRepositoriesComponent implements OnInit {

  private bookedRepos:Repository[] =[];
  private searchText:string =''

  constructor(private sh: SharedService,
    private router:Router) { }

  ngOnInit() {
    this.searchText = this.sh.searchedText;
    this.bookedRepos =   JSON.parse(sessionStorage.getItem(this.searchText) );

    console.log(this.bookedRepos)
  }

  //return to search page
  return(){
    sessionStorage.setItem(this.searchText ,'')
    this.router.navigate(['']);
  }
}
