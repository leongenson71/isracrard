
import { Router } from '@angular/router';
import { RepositoryService } from './../../services/RepositoryService';
import { Repository } from './../../services/Repository';
import { Component, OnInit,  AfterViewChecked } from '@angular/core';
import { SharedService } from 'src/app/services/shared-service';

@Component({
  selector: 'app-search-repository',
  templateUrl: './search-repository.component.html',
  styleUrls: ['./search-repository.component.css']
})
export class SearchRepositoryComponent implements OnInit{

  public searchText:string =''
  public isWasSearch:boolean =false
  public repositories:Repository[] =[];
  public bookedRepos:Repository[] =[];


  constructor(
    private service: RepositoryService,
    private sh: SharedService,
    private router:Router) { }

  ngOnInit() { }


  getRepositories(){
    //get repositories according this.searchText and show on page
    if (this.searchText === '')
      return;

    this.service.getRepository(this.searchText).subscribe(
      data=>{
        this.repositories = data['items'];
        this.sh.searchedText = this.searchText;

        this.isWasSearch = true;
        },
        error=>{
          this.sh.errMessage = error;
          this.router.navigate(['error']);
          this.isWasSearch = false;
        }
        );
  }

  bookmark(idNum:number){
    //add bookmarked repository to array of booked repositories
    this.bookedRepos.push(this.repositories.find(rep=>rep.id==idNum))
  }

  showBookmarked(){

    if (this.bookedRepos.length == 0)
      return;
    this.isWasSearch = false;
    //set array of booked repositories to  sessionStorage
    sessionStorage.setItem(this.searchText ,JSON.stringify(this.bookedRepos) );
    //navigate to bookmarked repositories page
    this.router.navigate(['bookmarked'])
  }
}
