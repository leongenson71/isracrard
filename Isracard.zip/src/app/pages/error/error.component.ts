import { SharedService } from 'src/app/services/shared-service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';


@Component({
  selector: 'app-error',
  templateUrl: './error.component.html',
  styleUrls: ['./error.component.css']
})
export class ErrorComponent implements OnInit {
  public errMsg:string;
  constructor( private sh: SharedService,
    private router:Router) { }

  ngOnInit() {
    //show error message
    this.errMsg = this.sh.errMessage;
  }


  return(){
    //return to search page
    this.router.navigate(['']);
  }
}
