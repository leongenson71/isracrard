import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SharedService {
  //shared data between components
  public errMessage: string ='';
  public searchedText:string = ''

  constructor() { }
}
