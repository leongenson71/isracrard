import { element } from 'protractor';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Injectable } from "@angular/core";
import { map } from 'rxjs/operators';
import { Repository } from './Repository';

@Injectable({providedIn:'root'})
export class RepositoryService {

  private baseUrl:string

  constructor(private http:HttpClient){
    this.baseUrl =  'https://api.github.com/search/repositories?q='
  }

  //get data from GitHub api
  public getRepository(searchText:string) :Observable< any[]> {
    return this.http.get<any[]>(`${this.baseUrl}${searchText}.json`)


  }
}


