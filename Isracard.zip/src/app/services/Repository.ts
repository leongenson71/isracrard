//class for repository
export class Repository{
   id:number;
   name:string;
   owner_avatar_url:string;


}
