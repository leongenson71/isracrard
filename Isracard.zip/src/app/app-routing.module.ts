import { ErrorComponent } from './pages/error/error.component';
import { BookMarkedRepositoriesComponent } from './pages/book-marked-repositories/book-marked-repositories.component';
import { SearchRepositoryComponent } from './pages/search-repository/search-repository.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


const routes: Routes = [
  {path:'', component:SearchRepositoryComponent},
  {path:'bookmarked', component:BookMarkedRepositoriesComponent},
  {path:'error',component:ErrorComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
